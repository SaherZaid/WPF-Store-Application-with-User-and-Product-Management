﻿using Labb3ProgTemplate.Enums;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Labb3ProgTemplate.Enums;

namespace Labb3ProgTemplate.DataModels.Users;

public class Admin : User
{
    public override UserTypes Type { get; }

    public Admin(string name, string password) : base(name, password)
    {
        this.Type = UserTypes.Admin; // Assigns the vale UserTypes.Admin to the Type property
    }

}